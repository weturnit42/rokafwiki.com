package com.freehoon.web.common;


public class Search extends Pagination{

	

	private String searchType;

	private String keyword;	

			

	public String getSearchType() {

		return searchType;

	}

	

	public void setSearchType(String searchType) {

		this.searchType = searchType;

	}

	

	public String getKeyword() {

		return keyword;

	}



	public void setKeyword(String keyword) {

		this.keyword = keyword;

	}

}